p1 = 18/38;
A = rand(1,500);
a1 = A > p1;
sum(a1)